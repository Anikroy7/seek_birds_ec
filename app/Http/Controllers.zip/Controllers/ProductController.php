<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Illuminate\Contracts\Session\Session;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    public function index()
    {
        $products = new Product();
        $data = $products->get();
        return  view('home.home', compact('data'));
    }
    public function product_details($id)
    {
        $product = Product::findOrFail($id);
        return view('productDetails.productDetails', compact('product'));
    }
    function cart_item(Request $request)
    {
        $products = [];
        $items = [];
        $total_price = 0;
        $total_items = 0;
        $itemsId = session()->get('productIds');
        if ($itemsId) {
            foreach ($itemsId as $index => $item) {
                foreach ($item as $key => $value) {
                    $product = Product::findOrFail($key);
                    $products[$index] = $product;
                    $items[$key] = $value;
                }
            }
        }
        // dd($products);
        if ($products && $items) {
            foreach ($products as $key => $value) {
                $total_price += $value->current_price * $items[$value->id];
            }
            foreach ($items as $key => $value) {
                $total_items += $value;
            }
        }
        if ($request->ajax()) {
            // If AJAX request, return JSON data
            return response()->json([
                'products' => $products,
                'items' => $items,
                'total_price' => $total_price,
                'total_items' => $total_items,
            ]);
        }
        // dd($total_price);
        return view('cart.cart', compact('products', 'items', 'total_price', 'total_items'));
    }
}
